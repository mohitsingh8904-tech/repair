from django.contrib import admin
from contactdetails.models import Contact
# Register your models here.
class Contactj(admin.ModelAdmin):
    list_display=('name','email','message','subject','created_at')
admin.site.register(Contact)
