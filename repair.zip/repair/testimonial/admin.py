from django.contrib import admin
from .models import Testimonial

admin.site.register(Testimonial)
