from django.db import models 
# Create your models here. 
class Technician (models.Model): 
    Technician_person = models.CharField( max_length=250) 
    Technician_post = models.CharField( max_length=250) 
    Technician_img = models.FileField(upload_to="technician", max_length=250, null=True, default=None)

def __str__(self):
    return self.Technician_person
