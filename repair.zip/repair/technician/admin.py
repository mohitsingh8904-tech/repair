from django.contrib import admin 
# Register your models here. 
from technician.models import Technician
class TechnicianAdmin(admin.ModelAdmin): 
     list_display=('Technician_person','Technician_post','Technician_img') 
admin.site.register(Technician,TechnicianAdmin) 