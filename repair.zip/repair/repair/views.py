from django.http import HttpResponse
from django.shortcuts import redirect, render
from Blogpage.models import Blog
from bookingpage.models import Booking
from contactdetails.models import Contact
from django.contrib import messages
from technician.models import Technician
from django.core.mail import send_mail 
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.template.loader import render_to_string
from django.core.mail import EmailMessage
import requests
from testimonial.models import Testimonial


def HomePage(request): 
    msg = ""
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('service')
        message = request.POST.get('Special_request')
        date = request.POST.get('date')

        alldata=Booking(  
            name=name,
            email=email,
            subject=subject,
            message=message,
            date=date
        )
        alldata.save()
        msg = "Your message was submitted successfully!"
    
    technicianData=Technician.objects.all() 
    testimonials = Testimonial.objects.all()
    
    return render(request, "index.html",{'technicianData':technicianData,'msg':msg,'testimonials':testimonials}) 

def aboutpage(request):
    technicianData = Technician.objects.all()
    return render(request, 'about.html', {'technicianData': technicianData})


def service(request):
   msg = ' '
   if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('service')
        message = request.POST.get('Special_request')
        date = request.POST.get('date')

        # Save booking data to database
        allData = Booking(
            name=name,
            email=email,
            subject=subject,
            message=message,
            date=date
        )
        allData.save()

        msg = 'Booking Submitted Successfully!'

        # -------- User Email (HTML) --------
        html_content = render_to_string(
            'template/booking_email_template.html',
            {
                'name': name,
                'email': email,
                'subject': subject,
                'message': message,
                'date': date,
            }
        )

        user_email = EmailMessage(
            subject="Booking Confirmation",
            body=html_content,
            from_email="ms8904794@gmail.com",
            to=[email],
        )
        user_email.content_subtype = "html"
        user_email.send(fail_silently=True)

        # -------- Admin Email (Plain Text) --------
        admin_message = (
            f"New Booking Received\n\n"
            f"Name: {name}\n"
            f"Email: {email}\n"
            f"Service: {subject}\n"
            f"Date: {date}\n"
            f"Special Request: {message}"
        )

        admin_email = EmailMessage(
            subject="New Booking",
            body=admin_message,
            from_email="ms8904794@gmail.com",
            to=["ms8904794@gmail.com"],
        )
        admin_email.send(fail_silently=True)

   return render(request, 'service.html', {'msg': msg})






def teampage(request):
    technicianData = Technician.objects.all()
    return render(request, 'team.html', {'technicianData': technicianData})

def testimonial(request):
    testimonials = Testimonial.objects.all()
    return render(request, 'testimonial.html', {'testimonials': testimonials})

def page404(request):
    return render(request, "404.html")




def contact(request):
    msg = ''
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')

        # Save form data to the database
        allData = Contact(
            name=name,
            email=email,
            subject=subject,
            message=message
        )
        allData.save()
        msg = 'Message Sent Successfully!'

        html_content = render_to_string('template/appemail_template.html',{
            'name' : name,
            'email' : email,
            'subject' : subject,
            'message' : message,   
        })

        user_email=EmailMessage(
            subject="thank you",
            body=html_content,
            from_email="ms8904794@gmail.com",
            to=[email],
        )
        user_email.content_subtype="html"
        user_email.send(fail_silently=True)

        

        message =(
            f"Name: {name}\n"
            f"email: {email}\n"
            f"Subject: {subject}\n"
            f"Message: {message}"
        )
        admin_email=EmailMessage(
         subject="New Contact",
         body=message,
         from_email="ms8904794@gmail.com",
         to=['ms8904794@gmail.com'],
        )
        admin_email.send(fail_silently=True)
    return render(request, 'contact.html', {'msg': msg})






   
def blogpage(request):
    blogData = Blog.objects.all()
    return render(request, 'blog.html', {'blogData': blogData})






def booking(request):
    msg = ''
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('service')
        message = request.POST.get('Special_request')
        date = request.POST.get('date')

        # Save booking data to database
        allData = Booking(
            name=name,
            email=email,
            subject=subject,
            message=message,
            date=date
        )
        allData.save()

        msg = 'Booking Submitted Successfully!'

        # -------- User Email (HTML) --------
        html_content = render_to_string(
            'template/booking_email_template.html',
            {
                'name': name,
                'email': email,
                'subject': subject,
                'message': message,
                'date': date,
            }
        )

        user_email = EmailMessage(
            subject="Booking Confirmation",
            body=html_content,
            from_email="ms8904794@gmail.com",
            to=[email],
        )
        user_email.content_subtype = "html"
        user_email.send(fail_silently=True)

        # -------- Admin Email (Plain Text) --------
        admin_message = (
            f"New Booking Received\n\n"
            f"Name: {name}\n"
            f"Email: {email}\n"
            f"Service: {subject}\n"
            f"Date: {date}\n"
            f"Special Request: {message}"
        )

        admin_email = EmailMessage(
            subject="New Booking",
            body=admin_message,
            from_email="ms8904794@gmail.com",
            to=["ms8904794@gmail.com"],
        )
        admin_email.send(fail_silently=True)

    return render(request, "booking.html", {'msg': msg})




def weather_view(request):
    # API URL (you can also build this dynamically, e.g. based on user input)
    api_key = "4ed6d31acdec4218964164023252411"  # ideally, store in settings.SECRET or .env
    url = f"https://api.weatherapi.com/v1/current.json?key={api_key}&q=Bhilwara&aqi=yes"
    
    # Make the API call
    try:
        resp = requests.get(url)
        resp.raise_for_status()
        data = resp.json()
    except requests.RequestException as e:
        # Handle errors (timeout, connection error, non-200 response)
        data = None
        print("Error fetching weather:", e)
    
    # Prepare context for template
    context = {}
    if data:
        context = {
            "location_name": data.get("location", {}).get("name"),
            "region": data.get("location", {}).get("region"),
            "country": data.get("location", {}).get("country"),
            "local_time": data.get("location", {}).get("localtime"),
            "temp_c": data.get("current", {}).get("temp_c"),
            "condition_text": data.get("current", {}).get("condition", {}).get("text"),
            "icon_url": data.get("current", {}).get("condition", {}).get("icon"),
            "wind_kph": data.get("current", {}).get("wind_kph"),
            "humidity": data.get("current", {}).get("humidity"),
            "aqi": data.get("current", {}).get("air_quality", {}).get("us-epa-index"),
        }
    else:
        context["error"] = "Could not fetch weather data."

    return render(request, "vehicle_info.html", context)
