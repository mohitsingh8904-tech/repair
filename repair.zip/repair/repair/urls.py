"""
URL configuration for repair project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from repair import views
from repair.views import contact
from django.conf import settings 
from django.conf.urls.static import static

urlpatterns = [

    path('admin/', admin.site.urls),
    path("",views.HomePage, name ="homepage" ),
    path("about/",views.aboutpage,name="about"),
    path("contact/",views.contact,name='contact'),
    path("service.html",views.service,name="service"),
    path('booking.html', views.booking, name='bookingpage'),
    path("team.html",views.teampage,name="team"),
    path("testimonial.html",views.testimonial,name="testimonial"),
    path("404.html",views.page404,name="page404"),
    path("blog.html",views.blogpage,name="blog"),
    path("vehicle_info.html", views.weather_view,name="vehicle_info"),
    path('car/', include('car.urls'))

     
]

if settings.DEBUG: 
    urlpatterns+=static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT) 