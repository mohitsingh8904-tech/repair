from django.urls import path
from . import views

urlpatterns = [
    path('', views.home_page),
    path('car/', views.get_car),
    path('add/', views.add_car),
    path('car/<int:id>/', views.get_car),
]
