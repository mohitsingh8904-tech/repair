from django.db import models

class car(models.Model):
    Name = models.CharField(max_length=100)
    Model = models.CharField(max_length=100)
    year = models.IntegerField()

def __str__(self):
 return self.name