from .models import car
from rest_framework import serializers

class carSerializer(serializers.ModelSerializer):
    class Meta:
        model = car
        fields = '__all__'

        