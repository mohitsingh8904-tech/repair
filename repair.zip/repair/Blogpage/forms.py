from django import forms
from .models import Blog

class Blogpage(forms.ModelForm):
    class Meta:
        model = Blog
        fields = ['blog_title','blog_author','blog_date','blog_image','og_description']