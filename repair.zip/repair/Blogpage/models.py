from django.db import models

class Blog(models.Model):
    blog_title = models.CharField(max_length=200)
    blog_author = models.CharField(max_length=100)
    blog_date = models.DateField(auto_now_add=True)
    blog_image = models.ImageField(upload_to='blog_images/')
    blog_description = models.TextField()

    def __str__(self):
        return self.blog_title
