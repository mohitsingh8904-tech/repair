from django import forms
from .models import Booking

class books(forms.ModelForm):
    class meta:
        model = Booking
        fields = ['name','email','subject','message','date','created_at']