from django.apps import AppConfig


class BookingpageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookingpage'
